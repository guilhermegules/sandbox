package com.example.alunos.exemplodettsestt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.speech.tts.TextToSpeech;
import android.widget.Toast;

import java.util.Locale;

public class TextToSpeechActivity extends AppCompatActivity {
    EditText edtTTS;
    TextToSpeech tts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_to_speech);
        edtTTS = (EditText) findViewById(R.id.edtTTS);

        tts=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.getDefault());
                }
            }
        });
    }

    public void abrirPrincipalTTS(View v){
        Intent iPrincipal = new Intent(this, PrincipalActivity.class);
        startActivity(iPrincipal);
    }

    public void narrar(View v){
        String textoDesejado = edtTTS.getText().toString();
        tts.speak(textoDesejado, TextToSpeech.QUEUE_FLUSH, null);
    }


}
