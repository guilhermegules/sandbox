package com.example.alunos.exemplodettsestt;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class SpeechToTextActivity extends AppCompatActivity {
    EditText edtSTT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speech_to_text);
        edtSTT = (EditText) findViewById(R.id.edtSTT);
    }

    public void abrirPrincipalSTT(View v){
        Intent iPrincipal = new Intent(this, PrincipalActivity.class);
        startActivity(iPrincipal);
    }

    public void reconhecer(View v) {
        Intent iCaptura = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        iCaptura.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        iCaptura.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        iCaptura.putExtra(RecognizerIntent.EXTRA_PROMPT, "Harãaa... Desembucha tchê!");
        try {
            startActivityForResult(iCaptura, 171);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(this, "Infelizmente seu Smartphone não suporta esse recurso.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 171: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    edtSTT.setText(result.get(0));
                    li.setBackgroundColor(Color.parseColor("#ffff00"));
                }
                break;
            }

        }
    }
}
