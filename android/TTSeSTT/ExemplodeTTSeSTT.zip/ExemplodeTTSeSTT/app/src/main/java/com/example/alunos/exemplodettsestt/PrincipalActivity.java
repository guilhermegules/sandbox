package com.example.alunos.exemplodettsestt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class PrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
    }

    public void abrirTTS(View v){
        Intent iTTS = new Intent(this, TextToSpeechActivity.class);
        startActivity(iTTS);
    }

    public void abrirSTT(View v){
        Intent iSTT = new Intent(this, SpeechToTextActivity.class);
        startActivity(iSTT);
    }
}
